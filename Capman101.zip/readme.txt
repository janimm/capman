
 CAPMAN V1.01						3.7.1999
 (c) Jani Immonen
 email: jani_immonen@hotmail.com
----------------------------------------------------------------------

Changes from version 1.0

16bit graphics should now work with all display adaptors.


----------------------------------------------------------------------
Command line switches
----------------------------------------------------------------------

-ForceNoSound 
Disables MIDAS digital audio system. If game won't start, you can try
this option to see if problem is sound related.

-Force8Bit
Use this if you changed display mode to 16bit, and game won't
start anymore



----------------------------------------------------------------------
List of known problems / features.
----------------------------------------------------------------------

If game is minimized (alt-tab or ctrl-esc) and restored back, changing
display mode (8/16bit) will cause following error message: 
DDInit: SetCooperativeLevel Failed. I haven't found the cause of this
problem yet. Although you can play game normally, just do not change
display mode after restoring game.

When using direct cable connection (via. comports), game crashes if
game host (player that created game) ends his/her game before all
joined player have done that. This problem seems to occur only with
cable connection, not with modem TCP/IP or IPX/SPX connections.
Reason for this is yet unknown.

When joining eatmatch game that has been on its way for a while,
players statusboxes might show different information on each machine.


----------------------------------------------------------------------
Distribution
----------------------------------------------------------------------

This Game is freeware. So copy, distribute and play it as you wish as
long as you won't take any payment for it. 

----------------------------------------------------------------------
Copyright & Disclaimer
----------------------------------------------------------------------

CAPMAN, AND INCLUDED CAPEDIT- LEVEL EDITOR ARE DISTRIBUTED "AS IS".
NO WARRANTY OF ANY KIND IS EXPRESSED OR IMPLIED. YOU USE THESE
SOFWARES AT YOUR OWN RISK. THE AUTHOR WILL NOT BE LIABLE FOR DATA
LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING
OR MISUSING THIS SOFTWARE. 
If you want to use this game in commercial purposes (cover cd etc.),
you must have permission from author. 
Copyright (c) 1999 Jani Immonen, All rights reserved.

